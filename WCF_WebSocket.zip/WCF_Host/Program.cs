using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.WebSockets;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.Text;
using System.Threading.Tasks;
using WCF_WebSocket;
using System.IO;

namespace WCF_Host
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                //HostService();

                //// add the service endpoint
               ServiceHost host = new ServiceHost(typeof(TestService));               
                host.Open();
                ////CustomBinding customBinding = new CustomBinding();
                ////customBinding.Elements.Add(new TextMessageEncodingBindingElement());
                ////customBinding.Elements.Add(new HttpTransportBindingElement());

                ////customBinding.SendTimeout = new TimeSpan(1, 59, 59);
                ////customBinding.ReceiveTimeout = new TimeSpan(1, 59, 59);
                ////host.AddServiceEndpoint(typeof(TestService), customBinding, "http://localhost:13060");

                //// service is ready for user

                Console.WriteLine("service hosted sucessfully hosted on {0}      ", "http://localhost:13060");
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                string[] arrStrings = new string[1];
                arrStrings[0] = ex.ToString();
                File.WriteAllLines(@"D:\error.txt", arrStrings);
                Console.ReadKey();
            }
           

        }


        private static void HostService()
        {
            try
            {
                Uri baseAddress = new Uri("http://localhost:13060");

                // Create the ServiceHost.
                using (ServiceHost host = new ServiceHost(typeof(TestService), baseAddress))
                {
                    // Enable metadata publishing.
                    ServiceMetadataBehavior smb = new ServiceMetadataBehavior();
                    smb.HttpGetEnabled = true;
                    smb.MetadataExporter.PolicyVersion = PolicyVersion.Policy15;
                    host.Description.Behaviors.Add(smb);

                    CustomBinding binding = new CustomBinding();
                    binding.Elements.Add(new TextMessageEncodingBindingElement());
                    HttpTransportBindingElement transport = new HttpTransportBindingElement();
                    //transport.WebSocketSettings = new WebSocketTransportSettings();
                    transport.WebSocketSettings.TransportUsage = WebSocketTransportUsage.Always;
                    transport.WebSocketSettings.CreateNotificationOnConnection = true;
                    binding.Elements.Add(transport);

                    host.AddServiceEndpoint(typeof(ITestService), binding, "");

                    host.Open();

                    Console.WriteLine("The service is ready at {0}", baseAddress);
                    Console.WriteLine("Press <Enter> to stop the service.");
                    Console.ReadLine();

                    // Close the ServiceHost.
                    host.Close();
                }
            }
            catch (Exception ex)
            {
                string[] arrStrings = new string[1];
                arrStrings[0] = ex.ToString();
                File.WriteAllLines(@"D:\error.txt", arrStrings);
                Console.ReadKey();
            }
        }
    }
}
