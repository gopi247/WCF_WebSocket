using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using WCF_WebSocket;

namespace WCF_Host
{
    class Program
    {
        static void Main(string[] args)
        {

            try
            {

                ServiceHost host = new ServiceHost(typeof(TestService));
                string str = host.BaseAddresses[0].ToString();
                host.Open();
                Console.WriteLine("service hosted sucessfully hosted on {0}..............", str);
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                string[] arrStrings = new string[1];
                arrStrings[0] = ex.ToString();
                File.WriteAllLines(@"D:\error.txt", arrStrings);
                Console.ReadKey();
            }
        }
    }
}
