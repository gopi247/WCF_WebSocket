﻿using System;

namespace ConsumeService
{
    class Program
    {
        static void Main(string[] args)
        {
            var client = new ServiceReference1.TestServiceClient();
           var x =  client.GetDataAsync("jhj");
            x.Wait();
            var oustr=x.Result;
            //Wrapper wrapper = new Wrapper();
            //wrapper.NetHttpBinding();
            //wrapper.Response();
        }

        private static void Wrapper_callBackString(object sender, string e)
        {
            Console.WriteLine(e);
            Console.WriteLine("\n");
        }
    }
}
